#!/usr/bin/env python

import re
import sys
import json
import socket
import urllib
import urllib2


SLACK_POST_URL = "https://hooks.slack.com/services/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"
ICON_URL = "http://www.damagedworkflow.com/cms/wordpress/wp-content/uploads/2013/02/PackageIcon.png"
USERNAME = "Deploy"

package = sys.argv[1]
owner_slack = sys.argv[2]
error = sys.argv[3]



# Build payload
if error == "0":
	payload = {
			"text": "Package *%s* deployed on %s" % (package,socket.gethostname()),
		}
else:
	try:
		with open ("install.log", "r") as fh: install_log = fh.readlines()
	except:
		install_log = "No install log available"
	try:
		with open ("install.options", "r") as fh: install_options = fh.readlines()
	except:
		install_options = "No install options file available"

	payload = {
			"text": "<@%s> ERROR package *%s* deploy failed on %s" % (owner_slack,package,socket.gethostname()),
			"fallback": "",
			"pretext": "Error details",
			"color": "danger",
			"channel": "#ecosystem-bp-feed",
			"fields": [
				],
		}

# Common payload options
payload['icon_url'] = ICON_URL
payload['username'] = USERNAME

# If this is running in UT1ECO then assume dev and send message direct
if re.match("...(ECO|KRAP|BEE)",socket.gethostname()):  payload['channel'] = "@%s" % owner_slack


# Submit request
req = urllib2.Request(SLACK_POST_URL, json.dumps(payload), {'Content-Type': 'application/json'})
f = urllib2.urlopen(req)

