#!/bin/bash

#
# Install and configure the data node
# The head node is set as $1
#

echo "Configuring head node $1"

