"""Console script entry point."""

import bpclient


def BPClient():

	bpclient.Args()
	bpclient.ExecCommand()


def BPMailer():

	print "bpmailer not yet implemented"
	import sys
	sys.exit(1)



