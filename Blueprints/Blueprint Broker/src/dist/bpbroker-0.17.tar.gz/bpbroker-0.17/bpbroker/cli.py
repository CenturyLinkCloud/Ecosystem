"""Console script entry point."""

import bpbroker


def BPBroker():

	bpbroker.Args()
	bpbroker.ExecCommand()



